To create Users and Groups in AAD, perform the following:
   1 - Identify credentials of an administrator in your AAd Domain
   2 - Edit the XLSx file to specify your users and groups
   3 - Save the fil as CSV
   4 - Execute the script: .\Create-AADusers-groups.ps1 -AADName <UPN of admin in AAD> -AADPassword <its password> -AaDUserCSV <Ptah to CSV file> 